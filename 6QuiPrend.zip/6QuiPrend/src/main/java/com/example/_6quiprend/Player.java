package com.example._6quiprend;

import java.util.ArrayList;
import lombok.*;
public class Player {
    @Getter @Setter ArrayList<Card> hand;
    @Getter @Setter int score;


}
