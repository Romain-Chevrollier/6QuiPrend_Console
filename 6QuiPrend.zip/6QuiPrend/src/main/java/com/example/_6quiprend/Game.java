package com.example._6quiprend;

import java.util.ArrayList;

public class Game{
    Deck Deck;
    Player player;


    public void startGame(){
        Player faker = new Player();
        Player IA = new Player();
        Row rowOne = new Row();
        Row rowTwo = new Row();
        Row rowThree = new Row();
        Row rowFour = new Row();
        newDeck(faker, IA, rowOne, rowTwo, rowThree, rowFour);
    }


    private void newDeck(Player faker, Player IA, Row rowOne, Row rowTwo, Row rowThree, Row rowFour){
        Deck deck = new Deck();
        for (Card i : Card.values()){
            ArrayList<Card> liste = deck.getCards();
            liste.add(i);
            deck.setCards(liste);
        }
        deck.shuffle();
        deck.drawCard(faker, IA, rowOne, rowTwo, rowThree, rowFour);
    }
}
