package com.example._6quiprend;

import java.util.ArrayList;
import lombok.*;
public class Row {
    @Getter @Setter ArrayList<Card> cards;

    public void addCard(Card card){
        ArrayList<Card> listCard = this.getCards();
    }
}
